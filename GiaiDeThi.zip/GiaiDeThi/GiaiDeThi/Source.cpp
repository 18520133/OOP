#include <iostream>
#include "Cdate.h"
using namespace std;
int main()
{
	cdate a;
	cin >> a;
	cout << a;
	cout << endl << a++;
	cout << endl << a;
	system("pause");
	return 0;
}