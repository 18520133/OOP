#include "cdate.h"
cdate::cdate(void)
{
}
cdate::~cdate(void)
{
}
bool cdate::check(const int &a, const int &b, const int &c)
{
	switch (b)
	{
	case 1:case 3:case 5: case 7: case 8: case 10: case 12:
		if (a <= 0 || a > 31) return false;
		break;
	case 4: case 6: case 9: case 11:
		if (a <= 0 || a > 30) return false;
		break;
	case 2:
		if (c % 400 == 0 || (c % 4 == 0 && c % 100 != 0))
		{
			if (a <= 0 || a > 29) return false;
		}
		else if (a <= 0 || a > 28) return false;
		break;
	default: return false;
	}
	return true;
}
istream &operator>>(istream &in, cdate &d)
{
	bool k;
	do {
		k = false;
		cout << "ngay ="; in >> d.ngay;
		cout << "thang="; in >> d.thang;
		cout << "nam  ="; in >> d.nam;
		k = d.check(d.ngay, d.thang, d.nam);
		if (k == false) cout << "khong hop le!\n";
	} while (!k);
	return in;
}

ostream &operator<<(ostream &out, const cdate& d)
{
	out << d.ngay << "/" << d.thang << "/" << d.nam;
	return out;
}

cdate cdate::operator++()
{
	ngay++;
	switch (thang)
	{
	case 1: case 3: case 5: case 7: case 8: case 10: case 12:
		if (ngay > 31)
		{
			ngay = 1;
			thang++;
			if (thang > 12)
			{
				nam++;
				thang = 1;
			}
		}
		break;
	case 4: case 6: case 9: case 11:
		if (ngay > 30)
		{
			ngay = 1;
			thang++;
		}
		break;
	case 2:
		if (nam % 400 == 0 || (nam % 4 == 0 && nam % 100 != 0))
		{
			if (ngay > 29)
			{
				ngay = 1;
				thang++;
			}
		}
		else
		{
			if (ngay > 28)
			{
				ngay = 1;
				thang++;
			}
		}
	}
	return *this;
}
cdate cdate::operator++(int)
{
	cdate t = *this;
	ngay++;
	switch (thang)
	{
	case 1: case 3: case 5: case 7: case 8: case 10: case 12:
		if (ngay > 31)
		{
			ngay = 1;
			thang++;
			if (thang > 12)
			{
				nam++;
				thang = 1;
			}
		}
		break;
	case 4: case 6: case 9: case 11:
		if (ngay > 30)
		{
			ngay = 1;
			thang++;
		}
		break;
	case 2:
		if (nam % 400 == 0 || (nam % 4 == 0 && nam % 100 != 0))
		{
			if (ngay > 29)
			{
				ngay = 1;
				thang++;
			}
		}
		else
		{
			if (ngay > 28)
			{
				ngay = 1;
				thang++;
			}
		}
	}
	return t;
}