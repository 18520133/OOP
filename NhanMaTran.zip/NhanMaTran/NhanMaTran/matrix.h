﻿#pragma once
class vector;
class matrix
{
private:
	int m; // dòng
	int n; // cột
	double **elements;
public:
	matrix();
	~matrix();
	matrix(const matrix & a);
	void nhap();
	void xuat();
	friend vector multiply(const matrix &a, const vector &b);
};