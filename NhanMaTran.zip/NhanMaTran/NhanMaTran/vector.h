#pragma once
class matrix;
class vector
{
private:
	double *coords;
	int n;
public:

	vector();
	vector(int N, double x);
	vector(const vector &a);
	~vector();
	void nhap();
	void xuat();
	friend vector multiply(const matrix &a, const vector &b);
};