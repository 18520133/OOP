#include <iostream>
using namespace std;
#include "vector.h"
#include "matrix.h"

vector multiply(const matrix &a, const vector &b)
{
	if (a.n != b.n)
	{
		cout << "Ko nhan duoc!\n";
		return vector(0, 0);
	}
	vector res(a.m, 0);
	res.n = a.m;
	for (int i = 0; i < a.m; i++)
	{
		res.coords[i] = 0;
		for (int j = 0; j < b.n; j++)
			res.coords[i] = res.coords[i] + b.coords[j] * a.elements[i][j];
	}
	return res;
}


int main()
{
	matrix C;
	C.nhap();
	vector D;
	D.nhap();
	vector RES = multiply(C, D);
	RES.xuat();
	system("pause");
	return 0;
}