#pragma once
#include "vector.h"
#include "matrix.h"
#include <iostream>
using namespace std;


vector::vector()
{
	coords = NULL;
}

vector::vector(int N, double x)
{
	n = N;
	coords = new double[n];
	for (int i = 0; i < n; i++)
		coords[i] = x;
}

vector::vector(const vector & a)
{
	n = a.n;
	coords = new double[n];
	for (int i = 0; i < n; i++)
		coords[i] = a.coords[i];
}


vector::~vector()
{
	if (coords != NULL)
		delete[] coords;
}

void vector::nhap()
{
	cin >> n;
	coords = new double[n];
	for (int i = 0; i < n; i++)
		cin >> coords[i];
}

void vector::xuat()
{
	for (int i = 0; i < n; i++)
		cout << roundf(coords[i] * 100) / 100 << " ";
	cout << endl;
}

