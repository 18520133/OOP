#pragma once
#include "vector.h"
#include "matrix.h"
#include <iostream>

using namespace std;

matrix::matrix()
{
	m = 0;
	n = 0;
	elements = NULL;
}

matrix::~matrix()
{
	if (elements == NULL)
		return;
	for (int i = 0; i < m; i++)
	{
		delete[] elements[i];
		elements[i] = NULL;
	}
	delete[] elements;
	elements = NULL;
}

matrix::matrix(const matrix & a)
{
	m = a.m;
	n = a.n;
	elements = new double *[m];
	for (int i = 0; i < m; i++)
		elements[i] = new double[n];
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			elements[i][j] = a.elements[i][j];
}

void matrix::nhap()
{
	cin >> m >> n;
	elements = new double *[m];
	for (int i = 0; i < m; i++)
		elements[i] = new double[n];
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			cin >> elements[i][j];
}

void matrix::xuat()
{
	cout << "Matrix: \n";
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			cout << elements[i][j] << " ";
		cout << endl;
	}
}