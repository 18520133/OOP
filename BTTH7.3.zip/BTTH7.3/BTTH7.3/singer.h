#pragma once
#include "person.h"
class singer :public person
{
private:
	string field;
public:
	singer();
	void input();
	void output();
	~singer();
};

