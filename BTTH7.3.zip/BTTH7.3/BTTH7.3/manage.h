#pragma once
#include"person.h"
class manage
{
private:
	int s;
	person **arr;
public:
	manage();
	~manage();
	void input();
	void output();
};

