#include "date.h"



date::date()
{
}
void date::input()
{
	cin >> d >> m >> y;
}
void date::output()
{
	cout << d << "/" << m << "/" << y;
}

date::~date()
{
}
