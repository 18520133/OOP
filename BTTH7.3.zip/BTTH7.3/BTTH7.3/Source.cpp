#include "artic.h"
#include "date.h"
#include "manage.h"
#include"person.h"
#include"pupil.h"
#include "singer.h"
#include"student.h"
#include"worker.h"
using namespace std;
int main()
{
	manage QL;
	QL.input();
	QL.output();
	system("pause");
	return 0;
}