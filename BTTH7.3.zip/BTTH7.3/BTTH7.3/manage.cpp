#include "manage.h"
#include <iostream>
#include "person.h"
#include "pupil.h"
#include "student.h"
#include "worker.h"
#include "artic.h"
#include "singer.h"


manage::manage()
{
}
void manage::input()
{
	cout << "s=";
	cin >> s;
	int flag;
	arr = new person *[s];
	for (int i = 0; i < s; i++)
	{
		cout << "1:pupil    2:student   3:worker   4:artic   5:singer";
		cin >> flag;
		switch (type)
		{
		case 1:
			arr[i] = new pupil();
			((pupil*)arr[i])->input();
			break;
		case 2:
			arr[i] = new student();
			((student*)arr[i])->input();
			break;
		case 3:
			arr[i] = new worker();
			((worker*)arr[i])->input();
			break;
		case 4:
			arr[i] = new artic();
			((artic*)arr[i])->input();
			break;
		case 5:
			arr[i] = new singer();
			((singer*)arr[i])->input();
			break;
		default:
			break;
		}


	}
}
void manage::output()
{
	for (int i = 0; i < s; i++)
	{
		switch (flag)
		{
		case 1:
			((pupil*)arr[i])->output();
			break;
		case 2:
			((student*)arr[i])->output();
			break;
		case 3:
			((worker*)arr[i])->output();
			break;
		case 4:
			((artic*)arr[i])->output();
			break;
		case 5:
			((singer*)arr[i])->output();
			break;
		default:
			break;
		}
	}
}
manage::~manage()
{
}
