#pragma once
#include <iostream>
#include <string>
#include "date.h"
using namespace std;
class person
{
protected:
	string name;
	date birth;
public:
	person();
	~person();
	int type;
	void input();
	void output();

};

