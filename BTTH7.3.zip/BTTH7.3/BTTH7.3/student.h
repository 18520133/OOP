#pragma once
#include "person.h"
class student :public person
{
private:
	string field;
public:
	student();
	void input();
	void output();
	~student();
};


