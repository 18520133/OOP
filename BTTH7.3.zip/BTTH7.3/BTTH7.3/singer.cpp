#include "singer.h"



singer::singer()
{
}
void singer::input()
{
	person::input();
	cin.ignore();
	cout << "Enter the field: ";
	getline(cin, field);

}
void singer::output()
{
	person::output();
	cout << field;
}

singer::~singer()
{
}
