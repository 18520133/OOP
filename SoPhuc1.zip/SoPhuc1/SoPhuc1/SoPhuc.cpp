#include "SoPhuc.h"


SoPhuc::SoPhuc()
{
}

SoPhuc::SoPhuc(float x, float y)
{
	this->thuc = x;
	this->ao = y;
}
SoPhuc::SoPhuc(SoPhuc &b)
{
	thuc = b.thuc;
	ao = b.ao;
}
void SoPhuc::Nhap()
{
	cout << "Nhap phan thuc: " << endl;
	cin >> this->thuc;
	cout << "Nhap phan ao: " << endl;
	cin >> this->ao;
}
void SoPhuc::Xuat()
{
	if (ao < 0)
		cout << this->thuc << "-" << this->ao << "i"<<endl;
	else
		cout << this->thuc << "+" << this->ao << "i"<<endl;
}
SoPhuc SoPhuc::Tong(SoPhuc b)
{
	SoPhuc c;
	c.thuc = this->thuc + b.thuc;
	c.ao = this->ao + b.ao;
	return c;
}
SoPhuc SoPhuc::Hieu(SoPhuc b)
{
	SoPhuc c;
	c.thuc = this->thuc - b.thuc;
	c.ao = this->ao - b.ao;
	return c;
}
SoPhuc SoPhuc::Nhan(SoPhuc b)
{
	SoPhuc c;
	c.thuc = this->thuc*b.thuc - this->ao*b.ao;
	c.ao = this->thuc*b.ao + this->ao*b.thuc;
	return c;
}
SoPhuc SoPhuc::Chia(SoPhuc b)
{
	SoPhuc c;
	c.thuc = (this->thuc*b.thuc + this->ao*b.ao) / (b.thuc*b.thuc + b.ao*b.ao);
	c.ao = (b.thuc*this->ao - this->thuc*b.ao) / (b.thuc*b.thuc + b.ao*b.ao);
	return c;
}
SoPhuc::~SoPhuc()
{
}
