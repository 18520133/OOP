#include "SoPhuc.h"

int main()
{
	SoPhuc sp1, Tong, Hieu;
	SoPhuc sp2, Nhan, Chia;
	sp1.Nhap();
	sp2.Nhap();
	Tong = sp1.Tong(sp2);
	Hieu = sp1.Hieu(sp2);
	Nhan = sp1.Nhan(sp2);
	Chia = sp1.Chia(sp2);
	cout << "Tong = ";
	Tong.Xuat();
	cout << "\nHieu = ";
	Hieu.Xuat();
	cout << "\nTich = ";
	Nhan.Xuat();
	cout << "\nThuong = ";
	Chia.Xuat();
	system("pause");
	return 0;
}