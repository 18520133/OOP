#pragma once
#include <iostream>
using namespace std;

class SoPhuc
{
private:
	float thuc;
	float ao;
public:
	SoPhuc();
	SoPhuc(float x, float y);
	SoPhuc(SoPhuc &b);
	void Nhap();
	void Xuat();
	float getthuc()
	{
		return thuc;
	}

	float getao()
	{
		return ao;
	}

	void setthuc(float x)
	{
		thuc = x;
	}
	void setao(float y)
	{
		ao = y;
	}
	SoPhuc Tong(SoPhuc b);
	SoPhuc Hieu(SoPhuc b);
	SoPhuc Nhan(SoPhuc b);
	SoPhuc Chia(SoPhuc b);
	~SoPhuc();
};

