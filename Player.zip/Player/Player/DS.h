#pragma once
#include "player.h"
#include <iostream>
#include <string>
class DS
{
private:
	int n;
	player *arr;
public:
	void Nhap();
	void Xuat();
	void mincao(player &a);
	void maxtien(player &a);
	DS();
	~DS();
};

