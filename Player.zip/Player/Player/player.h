#pragma once
#include <iostream>
#include <string>
using namespace std;
class player
{
private:
	string hoten;
	int dd,mm,yy;
	int cmnd;
	int gia;
	int cao;
	int solanchoi;
public:
	player();
	string gethoten();
	int getdd();
	int getmm();
	int getyy();
	int getcmnd();
	int getcao()
	{
		return cao;
	}
	int getgia();
	int getsolanchoi();
	player(player &a);
	void Nhap();
	void Xuat();
	~player();
};

