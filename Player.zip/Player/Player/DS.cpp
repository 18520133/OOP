#include "DS.h"
#include "player.h"
#include <iostream>
#include <string>


DS::DS()
{
}
void DS::Nhap()
{
	int n;
	cout << "Nhap so nguoi choi: ";
	cin >> n;
	arr = new player[n + 1];
	for (int i = 0; i < n; i++)
	{
		cout << "Nhap ngui choi thu " << i + 1 << " :" << endl;
		arr[i].Nhap();
	}
}
void DS::Xuat()
{
	cout << "/nDanh sach nguoi choi: ";
	for (int i = 0; i < n; i++)
	{
		arr[i].Xuat();
	}
}
void DS::mincao(player &a)
{
	player min;
	int x;
	x = arr[0].getcao();
	for (int i = 0; i < n; i++)
	{
		if (arr[i].getcao()*arr[1].getcao())
			min = arr[i];
	}
	min.Xuat();
}
void DS::maxtien(player &a)
{
	player max;
	int x;
	x = arr[0].getgia()*arr[0].getsolanchoi();
	for (int i = 0; i < n; i++)
	{
		if ((arr[i].getgia()*arr[i].getsolanchoi())>x)
			max = arr[i];
	}
	max.Xuat();
}
DS::~DS()
{
}
