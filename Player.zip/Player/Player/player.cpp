#include "player.h"
#include <iostream>
#include <string>
using namespace std;

player::player()
{
}
void player::Nhap()
{
	cout << "Ho ten: ";
	cin.ignore();
	getline(cin, hoten);
	cout << "/nNgay thang nam sinh: ";
	cin >> dd >> mm >> yy;
	if (2019-yy >= 16)
	{
		cout << "/nCMND: ";
		cin >> cmnd;
	}
	else
	{
		cmnd = 0;
		cin >> cmnd;
	}
	cout << "/nChieu cao(cm): ";
	cin >> cao;
	cout << "/nSo lan choi:";
	cin >> solanchoi;
}

void player::Xuat()
{
	cout << "Ho ten: " << hoten;
	cout << "/nNgay thang nam sinh: " << dd << "/" << mm << "/" << yy;
	cout << "/nCMND: " << cmnd;
	cout << "/nChieu cao: " << cao;
	if ((2019 - yy < 10) && (cao < 130))
	{
		gia = 50;
		cin >> gia;
	}
	else
	{
		gia = 100;
		cin >> gia;
	}
	cout << "/nSo lan choi: " << solanchoi;
}

player::~player()
{
}
