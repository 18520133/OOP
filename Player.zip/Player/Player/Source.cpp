#include <iostream>
#include <string>
#include "player.h"
#include "DS.h"
using namespace std;
int main()
{
	DS b;
	b.Nhap();
	b.Xuat();
	system("pause");
	return 0;
			
}