#pragma once
class PS
{
public:
	PS();
	~PS();
};

