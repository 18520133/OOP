#include<iostream>
#include "CDate.h"
using namespace std;
int main()
{
	CDate a, b;
	cout << "Nhap ngay thang nam 1: ";
	cin >> a;
	cout << "\nNhap ngay thang nam 2: ";
	cin >> b;
	int p;
	cout<< "\nSo ngay them bot :";
	cin >> p;
	cout << "a+p=" << a + p;
	cout << "a-p=" << a - p;
	/*
	a--;
	cout << "\nNgay thang nam tru 1: " << a;
	a++;
	cout << "\nNgay thang nam cong 1: " << a;
	*/
	system("pause");
	return 0;
}