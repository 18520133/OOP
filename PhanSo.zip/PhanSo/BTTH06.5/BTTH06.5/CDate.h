#pragma once
#include <iostream>
using namespace std;
class CDate
{
private:
	int ngay;
	int thang;
	int nam;
public:
	CDate();
	CDate(int d, int m, int y)
	{
		set(d, m, y);
	}
	void set(int d, int m, int y)
	{
		ngay = d;
		thang = m;
		nam = y;
	}
	friend istream& operator>>(istream &is, CDate &t);
	friend ostream& operator<<(ostream &os, CDate t);
	friend CDate operator+(CDate a,int t);
	friend CDate operator-(CDate a,int t);
	friend CDate operator++(CDate a);
	friend CDate operator--(CDate a);
	long long operator-(const CDate&);

	~CDate();
};

