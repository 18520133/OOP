#include "CDate.h"
#include <iostream>
using namespace std;

CDate::CDate()
{
}
istream& operator>>(istream &is, CDate &t)
{
	 cin >> t.ngay >> t.thang >> t.nam;
	 return is;
}
ostream& operator<<(ostream &os, CDate t)
{
	cout << t.ngay << "/" << t.thang << "/" << t.nam;
	return os;
}
CDate operator+(CDate a, int p)
{
	cout << "p=";
	cin >> p;
	int songay = a.ngay + p;
	do
	{
		switch (a.thang)
		{
		case 1:case 3:case 5:case 7:case 8: case 10:case 12:
			{
				if (songay > 31)
				{
					a.thang++;
					if (a.thang == 13)
					{
						a.thang = 1;
						a.nam++;
					}
					songay = songay - 31;
				}
				else
				{
					a.ngay = songay;
					songay = 0;
				}
				break;
			}
			case 2:
			{
				if (((a.nam % 4 == 0) && (a.nam % 100 != 0)) || (a.nam % 400 == 0))
				{
					if (songay > 29)
					{
						a.thang++;
						songay = songay - 29;
					}
					else
					{
						a.ngay = songay;
						songay = 0;
					}
				}
				else
				{
					if (songay > 28)
					{
						a.thang++;
						songay = songay - 28;
					}
					else
					{
						a.ngay = songay;
						songay = 0;
					}
					break;
				}
			}
			case 4:case 6: case 9:case 11:
			{
				if (songay > 30)
				{
					a.ngay = songay - 30;
					a.thang++;
				}
				else
				{
					a.ngay = songay;
					songay = 0;
				}
				break;
			}
		}
	} while (songay > 0);
	return a;
}
CDate operator-(CDate a, int p)
{
	cout << "p=";
	cin >> p;
	int songay =  p;
	do 
	{
		if (songay < a.ngay)
		{
			a.ngay = a.ngay - songay;
			songay = 0;
		}
		else
		{
			songay = songay - a.ngay;
			a.thang--;
			switch (a.thang)
			{
			case 1:case 3:case 5: case 7:case 8:case 10:case 12:
					a.ngay = 31;
					break;
				case 4:case 6:case 9:case 11:
					a.ngay = 30;
					break;
				case 2:
					if (((a.nam % 4 == 0) && (a.nam % 100 != 0)) || (a.nam % 400 == 0))
						a.ngay = 29;
					else
						a.ngay = 28;
					break;
				case 0:
					{
						a.ngay = 31;
						a.thang = 12;
						a.nam--;
					}
					break;
			}
		}
	} while (songay > 0);
	return a;
}
CDate operator++(CDate a)
{
	switch (a.thang)
	{
	case 1:case 3:case 5:case 7:case 8:case 10:case 12:
		if (a.ngay + 1 > 31)
		{
			a.ngay = 1;
			a.thang++;
		}
		else
			a.ngay = a.ngay + 1;
	case 2:
		if (((a.nam % 4 == 0) && (a.nam % 100 != 0)) || (a.nam % 400 == 0))
		{
			if (a.ngay + 1 > 29)
			{
				a.ngay = 1;
				a.thang = 3;
			}
			else
				a.ngay = a.ngay + 1;
		}
		else
			if (a.ngay + 1 > 28)
			{
				a.ngay = 1;
				a.thang = 3;
			}
			else
				a.ngay = a.ngay + 1;
	case 4:case 6:case 9:case 11:
		if (a.ngay + 1 > 30)
		{
			a.ngay = 1;
			a.thang++;
		}
		else
			a.ngay = a.ngay + 1;
	}
	return a;
}
CDate operator--(CDate a)
{
	switch (a.thang)
	{
	case 1:case 3:case 5:case 7:case 8:case 10:case 12:
		if (a.ngay - 1 == 0)
		{
			a.ngay = 30;
			a.thang--;
				if (a.thang == 0)
					a.ngay = 31;
			if (a.thang == 2)
				if (((a.nam % 4 == 0) && (a.nam % 100 != 0)) || (a.nam % 400 == 0))
					a.ngay = 29;
				else
					a.ngay = 28;
		}
		else
			a.ngay++;
	case 4:case 6:case 9:case 11:case 2:
		if (a.ngay - 1 == 0)
		{
			a.ngay = 31;
			a.thang--;
		}
		else
			a.ngay++;
	}
	return a;
}
long long CDate::operator-(const CDate &d)
	{
		CDate x;
		x.ngay = ngay;
		x.thang = thang;
		x.nam = nam;
		long long a = x.ngay;
		do {
			switch (x.thang)
			{
			case 1: case 3: case 5: case 7: case 8: case 10: case 12:
				a += 31;
				x.thang--;
				if (x.thang == 0)
				{
					x.nam--;
					x.thang = 12;
				}
				break;
			case 4: case 6: case 9: case 11:
				a += 30;
				x.thang--;
				break;
			case 2:
				if (x.nam % 400 == 0 || (x.nam % 4 == 0 && x.nam % 100 != 0))
				{
					a += 29;
					x.thang--;
				}
				else
				{
					a += 28;
					x.thang--;
				}
			}
		} while (x.nam > 0);

		x.ngay = d.ngay;
		x.thang = d.thang;
		x.nam = d.nam;
		long long b = x.ngay;
		do {
			switch (x.thang)
			{
			case 1: case 3: case 5: case 7: case 8: case 10: case 12:
				b += 31;
				x.thang--;
				if (x.thang == 0)
				{
					x.nam--;
					x.thang = 12;
				}
				break;
			case 4: case 6: case 9: case 11:
				b += 30;
				x.thang--;
				break;
			case 2:
				if (x.nam % 400 == 0 || (x.nam % 4 == 0 && x.nam % 100 != 0))
				{
					b += 29;
					x.thang--;
				}
				else
				{
					b += 28;
					x.thang--;
				}
			}
		} while (x.nam > 0);
		return a - b;
}


CDate::~CDate()
{
}
