#pragma once
#include "person.h"
class artic:public person
{
private:
	string field;
public:
	artic();
	void input();
	void output();
	~artic();
};

