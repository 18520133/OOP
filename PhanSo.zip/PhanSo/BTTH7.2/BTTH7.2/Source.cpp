#include <iostream>
#include "person.h"
#include "pupil.h"
#include "student.h"
#include "worker.h"
#include "artic.h"
#include "singer.h"
using namespace std;
int main()
{
	person *a;
	int t;
	cout << "1:pupil-2:student-3:worker-4:artic-5:singer";
	cin >> t;
	switch (t)
	{
	case 1:
		a = new student();
		((student*)a)->input();
		((student*)a)->output();
		break;
	case 2:
		a = new pupil();
		((pupil*)a)->input();
		((pupil*)a)->output();
		break;
	case 3:
		a = new worker();
		((worker*)a)->input();
		((worker*)a)->output();
		break;
	case 4:
		a = new artic();
		((artic*)a)->input();
		((artic*)a)->output();
		break;
	case 5:
		a = new singer();
		((singer*)a)->input();
		((singer*)a)->output();
		break;
	default:
		break;
	}
	cout << endl;
	system("pause");
	return 0;
}