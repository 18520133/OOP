#pragma once
#include "person.h"
class pupil:public person
{
private:
	string field;
public:
	pupil();
	void input();
	void output();
	~pupil();
};

