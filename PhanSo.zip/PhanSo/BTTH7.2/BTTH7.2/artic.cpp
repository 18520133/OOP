#include "artic.h"
#


artic::artic()
{
}
void artic::input()
{
	person::input();
	cin.ignore();
	cout << "Enter the field: ";
	getline(cin, field);

}
void artic::output()
{
	person::output();
	cout << field;
}

artic::~artic()
{
}
