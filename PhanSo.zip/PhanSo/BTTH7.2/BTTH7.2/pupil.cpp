#include "pupil.h"



pupil::pupil()
{
}
void pupil::input()
{
	person::input();
	cin.ignore();
	cout << "Enter the field: ";
	getline(cin, field);

}
void pupil::output()
{
	person::output();
	cout << field;
}

pupil::~pupil()
{
}
