#include "student.h"



student::student()
{
}
void student::input()
{
	person::input();
	cin.ignore();
	cout << "Enter the field: ";
	getline(cin, field);

}
void student::output()
{
	person::output();
	cout << field;
}

student::~student()
{
}
