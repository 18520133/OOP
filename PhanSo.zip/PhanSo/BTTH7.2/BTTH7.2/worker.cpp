#include "worker.h"



worker::worker()
{
}
void worker::input()
{
	person::input();
	cin.ignore();
	cout << "Enter the field: ";
	getline(cin, field);

}
void worker::output()
{
	person::output();
	cout << field;
}

worker::~worker()
{
}
