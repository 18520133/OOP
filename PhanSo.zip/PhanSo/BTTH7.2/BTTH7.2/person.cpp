#include "person.h"
using namespace std;


person::person()
{
}
void person::input()
{
	cout << "Type: ";
	cin >> type;
	cout << "\nName";
	cin.ignore();
	getline(cin, name);
	cout << "\nDOB";
	birth.input();
}
void person::output()
{
	cout << name << endl;
	birth.output();
}

person::~person()
{
}
