#include "date.h"
using namespace std;


date::date()
{
}
void date::input()
{
	cout << "DOB: ";
	cin >> d >> m >> y;
}
void date::output()
{
	cout << "DOB: " << d << "/" << m << "/" << y;
}

date::~date()
{
}
