#pragma once
#include "person.h"
class worker:public person
{
private:
	string field;
public:
	worker();
	void input();
	void output();
	~worker();
};

