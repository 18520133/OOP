#pragma once
#include <iostream>
#include <string>
#include "date.h"
using namespace std;
class person
{
protected:
	int type;
	string name;
	date birth;
public:
	person();
	~person();
	void input();
	void output();

};

