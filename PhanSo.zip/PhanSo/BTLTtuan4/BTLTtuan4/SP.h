#pragma once
class SP
{
private:
	string loaiSP;
	string tenSP;
	float gia;
	float giaban;
	int d, m, y;
	int dd, mm, yy;

public:
	SP();
	void Nhap();
	void Xuat();
	SP(SP &a);
	string getloaiSP();
	string gettenSP();
	float getgia();
	float getgiaban();
	int getd();
	int getm();
	int gety();
	int getdd();
	int getmm();
	int getyy();
	~SP();
};
