#include <iostream>
#include <string>
#include "DS.h"
#include "SP.h"
using namespace std;
int main()
{
	DS a;
	a.Nhap();
	for (int i = 0; i < a.getSLSP(); i++)
	{
		a.Xuat(i);
	}
	a.maxSP();
	SP minmp = a.minmypham();
	system("pause");
	return 0;
}