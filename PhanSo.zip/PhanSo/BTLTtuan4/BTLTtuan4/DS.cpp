#include "DS.h"
#include <iostream>
#include <string>
#include "SP.h"
using namespace std;



DS::DS()
{
	SLSP = 0;
	tenCH = "A";
	diachi = "Long An";
	//DS = NULL;
}

void DS::Nhap()
{
	cout << "So luong san pham: ";
	cin >> this->SLSP;
	arr = new SP[this->SLSP];
}

void DS::Xuat(int i)
{
	arr[i].Xuat();
}

SP DS::maxSP()
{
	int lc = 0;
	for (int i = 0; i < SLSP; i++)
	{
		if (arr[i].getgiaban() > arr[lc].getgiaban())
			lc = i;
	}
	return arr[lc];
}

SP DS::minmypham()
{
	for (int i = 0; i < SLSP; i++)
		if (arr[i].gettenSP() == "my pham")
		{
			float min = arr[i].getgiaban();
			if (arr[i].getgiaban() < min)
				min = arr[i].getgiaban();
		}
}

DS::~DS()
{
}