#pragma once
#include "SP.h"
class DS
{
private:
	int SLSP;
	string tenCH;
	string diachi;
	SP *arr;
public:
	DS();
	int getSLSP();
	DS(DS &a);
	void Nhap();
	void Xuat(int i);
	SP maxSP();
	SP minmypham();
	~DS();
};
