#include "SP.h"
#include <iostream>
#include <string>
using namespace std;

SP::SP()
{
}

void SP::Nhap()
{
	cout << "Loai san pham: ";
	cin.ignore;
	getline(cin, this->loaiSP);
	cout << "/nTen san pham: ";
	cin.ignore;
	getline(cin, this->tenSP);
	cout << "/nGia san pham: ";
	cin >> this->gia;
	cout << "/nNgay san xuat: ";
	cin >> d >> m >> y;
	cout << "/nNgay het han: ";
	cin >> dd >> mm >> yy;
}

void SP::Xuat()
{
	cout << "Loai san pham: " << this->loaiSP;
	cout << "/Ten san pham: " << this->tenSP;
	cout << "/nGia san pham: " << this->gia;
	cout << "/nNgay san xuat: " << this->d << "/" << this->m << "/" << this->y;
	cout << "/nNgay het han: " << this->dd << "/" << this->mm << "/" << this->yy;
}

float SP::getgiaban()
{
	if (tenSP == "thuc pham")
		giaban = gia - gia / 10;
	if (tenSP == " my pham")
		giaban = gia - gia / 15;
	else
		giaban = gia - gia / 5;
	return giaban;
}

SP::~SP()
{
}