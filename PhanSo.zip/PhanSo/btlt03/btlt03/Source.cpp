#include "book.h"
#include <string>
#include <iostream>
int main()
{
	book a;
	a.Nhap();
	a.Xuat();
	system("pause");
	return 0;
}