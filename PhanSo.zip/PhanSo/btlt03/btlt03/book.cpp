#include "book.h"
#include <string>
#include <iostream>
using namespace std;



book::book()
{
}
void book::Nhap()
{
	cout << "The loai: " << endl;
	cin.ignore();
	getline(cin, theloai);
	cout << "Tac gia: " << endl;
	cin.ignore();
	getline(cin, tacgia);
	cout << "Ten sach: " << endl;
	cin.ignore();
	getline(cin, tensach);
	cout << "Nam xuat ban: " << endl;
	cin >> this->namxuatban;
}
void book::Xuat()
{
	cout << "The loai: " << this->theloai << endl;
	cout << "Tac gia: " << this->tacgia << endl;
	cout << "Ten sach: " << this->tensach << endl;
	cout << "Nam xuat ban: " << this->namxuatban << endl;
}

book::~book()
{
}

