#pragma once
#include<iostream>
#include<string>

using namespace std;

class book
{
private:
	string theloai;
	string tacgia;
	int namxuatban;
	string tensach;
public:
	book();
	void Nhap();
	void Xuat();
	string gettheloai();
	string gettacgia();
	int getnam()
	{
		return namxuatban;
	}
	string gettensach();
	book(const book &x)
	{
		this->theloai=x.theloai;
		this->tacgia=x.tacgia;
		this->tensach=x.tensach;
		this->namxuatban=x.namxuatban;
	}

	~book();
};

