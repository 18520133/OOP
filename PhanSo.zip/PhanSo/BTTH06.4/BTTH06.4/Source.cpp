#include <iostream>
#include "CTime.h"
using namespace std;
int main()
{
	CTime a, b;
	cout << "Nhap gio phut giay 1: ";
	cin >> a;
	cout << "\nNhap gio phut giay 2:";
	cin >> b;
	CTime c;
	c = a + b;
	cout << "\na+b=" << c;
	c = a - b;
	cout << "\na-b=" << c;
	++a;
	cout << "\na++=" << a;
	--a;
	cout << "\na--=" << a;
	system("pause");
	return 0;
}