#pragma once
#include <iostream>
#include <math.h>
using namespace std;
class CTime
{
private:
	int gio, phut, giay;
public:
	CTime();
	CTime(int h, int m, int s)
	{
		set(h, m, s);
	}
	void set(int h, int m, int s)
	{
		gio = h;
		phut = m;
		giay = s;
	}
	friend istream& operator>>(istream &is, CTime &t);
	friend ostream& operator<<(ostream &os, CTime t);
	friend bool operator==(CTime a, CTime b);
	friend bool operator!=(CTime a, CTime b);
	friend bool operator>(CTime a, CTime b);
	friend bool operator>=(CTime a, CTime b);
	friend bool operator<(CTime a, CTime b);
	friend bool operator<=(CTime a, CTime b);
	friend CTime operator+(CTime a, CTime b);
	friend CTime operator-(CTime a, CTime b);
	friend void operator++(CTime &a);
	friend void operator--(CTime &a);
	~CTime();
};

