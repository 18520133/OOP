#include "CTime.h"
#include <iostream>
using namespace std;


CTime::CTime()
{
}
istream& operator>>(istream &is, CTime &t)
{
	do
	{
		cin >> t.gio >> t.phut >> t.giay;
	} while ((t.giay >= 60) && (t.phut >= 60));
	return is;
}
ostream& operator<<(ostream &os, CTime t)
{
	cout << t.gio << "h" << t.phut << "m" << t.giay << "s";
	return os;
}
bool operator==(CTime a, CTime b)
{
	if ((a.gio * 3600 + a.phut * 60 + a.giay) == (b.gio * 3600 + b.phut * 60 + b.giay))
		return true;
	else
		return false;
}
bool operator!=(CTime a, CTime b)
{
	if ((a.gio * 3600 + a.phut * 60 + a.giay) != (b.gio * 3600 + b.phut * 60 + b.giay))
		return true;
	else
		return false;
}
bool operator>(CTime a, CTime b)
{
	if ((a.gio * 3600 + a.phut * 60 + a.giay) > (b.gio * 3600 + b.phut * 60 + b.giay))
		return true;
	else
		return false;
}
bool operator>=(CTime a, CTime b)
{
	if ((a.gio * 3600 + a.phut * 60 + a.giay) >= (b.gio * 3600 + b.phut * 60 + b.giay))
		return true;
	else
		return false;
}
bool operator<(CTime a, CTime b)
{
	if ((a.gio * 3600 + a.phut * 60 + a.giay) < (b.gio * 3600 + b.phut * 60 + b.giay))
		return true;
	else
		return false;
}
bool operator<=(CTime a, CTime b)
{
	if ((a.gio * 3600 + a.phut * 60 + a.giay) <= (b.gio * 3600 + b.phut * 60 + b.giay))
		return true;
	else
		return false;
}
CTime operator+(CTime a, CTime b)
{
	CTime c;
	c.giay = a.giay + b.giay;
	c.phut = a.phut + b.phut;
	c.gio = a.gio + b.gio;
	if (c.giay >= 60)
	{
		c.phut = c.phut + c.giay % 60;
		c.giay = c.giay - c.giay % 60 * 60;
	}
	if (c.phut >= 60)
	{
		c.gio = c.gio + c.phut % 60;
		c.phut = c.phut - c.phut % 60 * 60;
	}
	return c;
}
CTime operator-(CTime a, CTime b)
{
	CTime c;
	if (a.giay - b.giay < 0)
	{
		c.giay = a.giay + 60 - b.giay;
		c.phut = a.phut - 1;
	}
	else
		c.giay = a.giay - b.giay;
	if (a.phut - b.phut < 0)
	{
		c.phut = a.phut + 60 - b.phut;
		c.gio = c.gio - 1;
	}
	else
		c.phut = a.phut - b.phut;
	return c;
}
void operator++(CTime &a)
{
	if (a.giay + 1 >= 60)
	{
		a.giay = 0;
		a.phut = a.phut + 1;
	}
	else
	{
		a.giay = a.giay + 1;
	}
	if (a.phut >= 60)
	{
		a.phut = 0;
		a.gio = a.gio + 1;
	}
}
void operator--(CTime &a)
{
	if (a.giay - 1 < 0)
	{
		a.giay = 59;
		a.phut = a.phut - 1;
	}
	else
	{
		a.giay = a.giay - 1;
	}
	if (a.phut >= 60)
	{
		a.phut = 0;
		a.gio = a.gio + 1;
	}
}

CTime::~CTime()
{
}
