#pragma once
#include <iostream>
#include <math.h>
using namespace std;
class sophuc
{
private:
	float thuc;
	float ao;
public:
	sophuc();
	/*{
		set(t, a);
	}*/
	sophuc(float t)
	{
		set(t, 0);
	}
	void set(float t, float a)
	{
		thuc = t;
		ao = a;
	}
	float kc()
	{
		return (sqrt(thuc*thuc + ao * ao));
	}
	friend istream& operator>>(istream &is, sophuc &p);
	friend ostream& operator<<(ostream &os, sophuc p);
	friend bool operator==(sophuc a, sophuc b);
	friend bool operator!=(sophuc a, sophuc b);
	friend sophuc operator+(sophuc a, sophuc b);
	friend sophuc operator-(sophuc a, sophuc b);
	friend sophuc operator*(sophuc a, sophuc b);
	friend sophuc operator/(sophuc a, sophuc b);
	friend bool operator>(sophuc a, sophuc b);
	friend bool operator>=(sophuc a, sophuc b);
	friend bool operator<(sophuc a, sophuc b);
	friend bool operator<=(sophuc a, sophuc b);
	~sophuc();
};