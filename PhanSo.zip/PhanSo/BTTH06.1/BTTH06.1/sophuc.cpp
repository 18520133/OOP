#include "sophuc.h"
#include <iostream>
#include <math.h>
using namespace std;
sophuc::sophuc()
{
}
istream& operator>>(istream &is, sophuc &p)
{
	is >> p.thuc >> p.ao;
	return is;
}
ostream& operator<<(ostream &os, sophuc p)
{
	os << p.thuc;
	if (p.ao < 0)
		os << p.ao << "i";
	else
		os << " + " << p.ao << "i";
	return os;
}
bool operator==(sophuc a, sophuc b)
{
	if ((a.ao == b.ao) && (a.thuc == b.thuc))
		return true;
	else return false;
}
bool operator!=(sophuc a, sophuc b)
{
	if ((a.ao == b.ao) && (a.thuc == b.thuc))
		return false;
	else return true;
}
bool operator>(sophuc a, sophuc b)
{
	if (a.kc() > b.kc())
		return true;
	return false;
}
bool operator>=(sophuc a, sophuc b)
{
	if (a.kc() >= b.kc())
		return true;
	return false;
}
bool operator<(sophuc a, sophuc b)
{
	if (a.kc() < b.kc())
		return true;
	return false;
}
bool operator<=(sophuc a, sophuc b)
{
	if (a.kc() <= b.kc())
		return true;
	return false;
}
sophuc operator+(sophuc a, sophuc b)
{
	sophuc c;
	c.ao = a.ao + b.ao;
	c.thuc = a.thuc + b.thuc;
	return c;
}
sophuc operator-(sophuc a, sophuc b)
{
	sophuc c;
	c.thuc = a.thuc - b.thuc;
	c.ao = a.ao - b.ao;
	return c;
}
sophuc operator*(sophuc a, sophuc b)
{
	sophuc c;
	c.thuc = a.thuc*b.thuc - a.ao*b.ao;
	c.ao = a.ao*b.thuc + a.thuc*b.ao;
	return c;
}
sophuc operator/(sophuc a, sophuc b)
{
	sophuc c;
	c.ao = (a.thuc*b.thuc + a.ao*b.ao) / (b.thuc*b.thuc + b.ao*b.ao);
	c.thuc = (b.thuc*a.ao - a.thuc*b.ao) / (b.thuc*b.thuc + a.ao*b.ao);
	return c;
}
sophuc::~sophuc()
{
}