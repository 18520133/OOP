#include <iostream>
#include "sophuc.h"
int main()
{
	sophuc a, b;
	cout << "Nhap so phuc a:";
	cin >> a;
	cout << "Nhap so phuc b:";
	cin >> b;
	cout << a << endl;;
	cout << b;
	sophuc c;
	c = a + b;
	cout << "\na+b=" << c;
	c = a - b;
	cout << "\na-b=" << c;
	c = a * b;
	cout << "\na*b=" << c;
	c = a / b;
	cout << "\na/b=" << c;
	if (a == b)
		cout << "\na=b\n";
	else cout << "\na!=b\n";
	system("pause");
	return 0;
}