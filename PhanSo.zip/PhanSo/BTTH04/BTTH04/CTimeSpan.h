#pragma once
using namespace std;
class CTimeSpan
{
private:
	int gio, phut, giay;
public:
	CTimeSpan();
	void Nhap();
	void Xuat();
	CTimeSpan(&b);
	CTimeSpan Cong(CTimeSpan b);
	CTimeSpan Tru(CTimeSpan b);
	~CTimeSpan();
};

