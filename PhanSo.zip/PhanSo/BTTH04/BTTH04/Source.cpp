#include "CTimeSpan.h"
#include <iostream>
using namespace std;
int main()
{
	CTimeSpan Tong, Hieu, t1, t2;
	t1.Nhap();
	t2.Nhap();
	Tong = t1.Cong(t2);
	Hieu = t1.Tru(t2);
	cout << "Tong thoi gian:";
	Tong.Xuat();
	cout << "Hieu thoi gian:";
	Hieu.Xuat();
	system("pause");
	return 0;
}

