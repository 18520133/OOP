#include "CTimeSpan.h"
#include <iostream>
using namespace std;


/*CTimeSpan::CTimeSpan()
{
}*/

void CTimeSpan::Nhap()
{
	cout << "Nhap khoang thoi gian: ";
	cin >> gio >> phut >> giay;
}
void CTimeSpan::Xuat()
{
	cout << gio << "h" << phut << "m" << giay << "s" << endl;
}
CTimeSpan CTimeSpan::Cong(CTimeSpan b)
{
	CTimeSpan c;
	c.giay = this->giay + b.giay;
	c.phut = this->phut + b.phut;
	c.gio = this->gio + b.gio;
	if (c.giay >= 60)
		c.phut++;
	if (c.phut >= 60)
		c.gio++;
	return c;
}

CTimeSpan CTimeSpan::Tru(CTimeSpan b)
{
	CTimeSpan c;
	c.giay = this->giay - b.giay;
	c.phut = this->phut - b.phut;
	c.gio = this->gio - b.gio;
	if (c.giay < 0)
	{
		c.giay = c.giay + 60;
		c.phut--;
		c.phut = c.phut + 60;
	}
	if (c.phut <= 0)
		c.gio++;
	return c;
}



CTimeSpan::~CTimeSpan()
{
}
