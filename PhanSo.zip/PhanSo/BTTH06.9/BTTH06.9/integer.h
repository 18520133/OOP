#pragma once
#include<iostream>
using namespace std;
class integer
{
private:
	float x;
public:
	integer();
	~integer();
	friend istream& operator>>(istream &is, const integer&);
	friend ostream& operator<<(ostream &os, const integer&);
	integer operator+(const integer&);
	integer operator-(const integer&);
	integer operator*(const integer&);
	integer operator/(const integer&);
	void operator++();
	void operator--();
};

