#include "integer.h"



integer::integer()
{
}
istream &operator>>(istream &is, integer &a)
{
	cin >> a.x;
	return is;
}
ostream &operator<<(ostream &os, const integer &a)
{
	cout << a.x;
	return os;
}

integer integer::operator+(const integer &a)
{
	integer z;
	z.x = this->x + a.x;
	return z;
}
integer integer::operator-(const integer &a)
{
	integer z;
	z.x = this->x - a.x;
	return z;
}
integer integer::operator*(const integer &a)
{
	integer z;
	z.x = this->x*a.x;
	return z;
}
integer integer::operator/(const integer &a)
{
	integer z;
	z.x = this->x / a.x;
	return z;
}
void integer::operator++()
{
	x++;
}
void integer::operator--()
{
	x--;
}

integer::~integer()
{
}
