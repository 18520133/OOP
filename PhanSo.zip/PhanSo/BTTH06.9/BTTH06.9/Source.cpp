#include"integer.h"
void main()
{
	integer x, y;
	cin >> x >> y;
	cout << x + y << endl;
	cout << x - y << endl;
	cout << x * y << endl;
	cout << x / y << endl;
	x++; y--;
	cout << x << " " << y;
	system("pause");
}