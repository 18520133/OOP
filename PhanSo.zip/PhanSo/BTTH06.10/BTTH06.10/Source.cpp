#include"MYINT.h"
void main()
{
	MYINT x, y;
	cin >> x >> y;
	cout << x + y << endl;
	cout << x - y << endl;
	system("pause");
}