#pragma once
#include<iostream>
using namespace std;
class MYINT
{
private:
	float x;
public:
	MYINT(void);
	~MYINT(void);
	friend ostream &operator<<(ostream &out, const MYINT&);
	friend istream &operator>>(istream &in, MYINT&);
	MYINT operator+(const MYINT&);
	MYINT operator-(const MYINT&);
	MYINT operator*(const MYINT&);
	MYINT operator/(const MYINT&);
	void operator++();
	void operator--();
};
