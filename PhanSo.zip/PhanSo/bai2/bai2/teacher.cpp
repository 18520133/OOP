#include "teacher.h"
#include <iostream>
#include "people.h"
using namespace std;

teacher::teacher()
{
	flag = 2;
}
void teacher::input()
{
	people::input();
	cin >> lesson;
}
void teacher::output()
{
	people::output();
	cout << lesson << "tiet";
}
int teacher::getlesson()
{
	return lesson;
}
teacher::~teacher()
{
}
