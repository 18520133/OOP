#include "school.h"
#include <iostream>
using namespace std;

school::school()
{
}
void school::input()
{
	cout << "n=";
	cin >> n;
	int flag;
	arr = new people*[n];
	for (int i = 0; i < n; i++)
	{
		cout << "1/Sinh vien 2/Giang vien";
		cin >> flag;
		switch (flag)
		{
		case 1:
			arr[i] = new student();
			arr[i]->input();
			break;
		case 2:
			arr[i] = new teacher();
			arr[i]->input();
			break;
		default:
			break;
		}
	}
}

void school::maxlesson(people a)
{
	int max=0, index;
	for (int i = 0; i < n; i++)
	{
		if (arr[i]->flag == 2)
		{
			if (arr[i]->getlesson() > max)
				max = arr[i]->getlesson();
		}
		index = i;
	}
	cout << arr[index];
}
void school::maxpoint(people a)
{
	int max=0, index;
	for (int i = 0; i < n; i++)
	{
		if (arr[i]->flag == 1)
		{
			if (arr[i]->getsex == 0)
			{
				if (arr[i]->getdtb > max)
					max = arr[i]->getdtb();
			}
		}
		index = i;
	}
	cout << arr[index];
}
void school::output()
{
	cout << "Giang vien co nhieu so tiet nhat: ";
	int max, index;
	for (int i = 0; i < n; i++)
	{
		if (arr[i]->flag == 2)
		{
			if (arr[i]->getlesson > max)
				max = arr[i]->getlesson();
		}
		index = i;
	}
	cout << arr[index];
	cout << "\nSinh vien nu co dtb cao nhat: ";
	int max1, index1;
	for (int i = 0; i < n; i++)
	{
		if (arr[i]->flag == 1)
		{
			if (arr[i]->getsex == 0)
			{
				if (arr[i]->getdtb > max1)
					max1 = arr[i]->getdtb();
			}
		}
		index1 = i;
	}
	cout << arr[index];
}
school::~school()
{
}
