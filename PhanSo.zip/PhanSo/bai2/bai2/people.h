#pragma once
#include<iostream>
#include<string>
using namespace std;
class people
{
protected:
	string name;
	int sex;
public:
	people();
	int flag;
	virtual int getlesson();
	virtual int getsex();
	virtual float getdtb();
	virtual void input();
	virtual void output();
	~people();
};

