#pragma once
#include"people.h"
#include "student.h"
#include "teacher.h"
using namespace std;
class school
{
private:
	int n;
	people **arr;
public:
	school();
	void input();
	void output();
	void maxlesson(people a);
	void maxpoint(people a);
	~school();
};

