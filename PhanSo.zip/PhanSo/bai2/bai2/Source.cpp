#include <iostream>
#include <string>
#include "people.h"
#include "school.h"
#include "student.h"
#include "teacher.h"
using namespace std;
int main()
{
	school QL;
	QL.input();
	QL.output();
	system("pause");
	return 0;
}