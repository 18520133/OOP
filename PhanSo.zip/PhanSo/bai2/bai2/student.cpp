#include "student.h"
#include <iostream>
#include <string>
using namespace std;


student::student()
{
	flag = 1;
}
void student::input()
{
	people::input();
	cout << "Nhap diem oop: ";
	cin >> oop;
	cout << "/nNhap diem nmlt: ";
	cin >> nmlt;
	cout << "/nNhap diem ctdl: ";
	cin >> ctdl;
}
void student::output()
{
	people::output();
	cout << "\nDiem oop, nmlt, ctdl lan luot la :" << oop << " " << nmlt << " " << ctdl;
}
int student::getsex()
{
	return sex;
}
float student::dtb()
{
	float dtb = (oop + nmlt + ctdl) / 3;
	return dtb;
}
student::~student()
{
}
