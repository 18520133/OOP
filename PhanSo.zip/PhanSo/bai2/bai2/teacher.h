#pragma once
#include "people.h"
class teacher: public people
{
private:
	int lesson;
public:
	teacher();
	void input();
	void output();
	int getlesson();
	~teacher();
};

