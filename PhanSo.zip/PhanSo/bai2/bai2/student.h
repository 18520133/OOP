#pragma once
#include <iostream>
#include"people.h"
using namespace std;
class student: public people
{
private:
	float oop;
	float nmlt;
	float ctdl;
public:
	student();
	int flag;
	int getsex();
	float dtb();
	void input();
	void output();
	~student();
};

