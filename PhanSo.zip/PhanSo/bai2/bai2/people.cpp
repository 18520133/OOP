#include "people.h"
#include <iostream>
#include <string>
using namespace std;


people::people()
{
}
void people::input()
{
	cout << "Ho ten: ";
	cin.ignore();
	getline(cin, name);
	cout << "Gioi tinh: 0/Nu 1/Nam ";
	cin >> sex;
}
int people::getlesson()
{

}
int people::getsex()
{

}
float people::getdtb()
{

}
people::~people()
{
}
