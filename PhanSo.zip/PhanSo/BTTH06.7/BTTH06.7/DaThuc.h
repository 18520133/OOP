﻿#pragma once
#include<iostream>
using namespace std;
class DaThuc
{
private:
	int n;//Bậc cao nhất của đa thức 
	float *heso;//Hệ số của đa thức 
	// Đa thức có dạng: "a0*x^0+a1*x^1+a2*x^2+..+an*x^n" 
public:
	friend istream&operator>>(istream &is, DaThuc &a) {
		is >> a.n;
		a.heso = new float[a.n];
		for (int i = 0; i <= a.n; i++) {
			is >> a.heso[i];
		}
		return is;
	}
	friend ostream&operator<<(ostream &os, DaThuc a) {
		for (int i = 0; i <= a.n; i++) {
			os << a.heso[i] << "x^" << i;
			if (i < a.n) os << "+";
		}
		return os;
	}
	DaThuc operator +(DaThuc b) {
		DaThuc c;
		if (this->n <= b.n) {
			c.n = b.n;
			c.heso = new float[c.n];
			for (int i = 0; i <= b.n; i++) {
				c.heso[i] = b.heso[i];
			}
			for (int i = 0; i <= this->n; i++) {
				c.heso[i] = this->heso[i] + b.heso[i];
			}
		}
		else {
			c.n = this->n;
			c.heso = new float[c.n];
			for (int i = 0; i <= this->n; i++) {
				c.heso[i] = this->heso[i];
			}
			for (int i = 0; i <= b.n; i++) {
				c.heso[i] = this->heso[i] + b.heso[i];
			}
		}
		return c;
	}
	DaThuc operator -(DaThuc b) {
		DaThuc c;
		if (this->n <= b.n) {
			c.n = b.n;
			c.heso = new float[c.n];
			for (int i = 0; i <= b.n; i++) {
				c.heso[i] = b.heso[i];
			}
			for (int i = 0; i <= this->n; i++) {
				c.heso[i] = this->heso[i] - b.heso[i];
			}
		}
		else {
			c.n = this->n;
			c.heso = new float[c.n];
			for (int i = 0; i <= this->n; i++) {
				c.heso[i] = this->heso[i];
			}
			for (int i = 0; i <= b.n; i++) {
				c.heso[i] = this->heso[i] - b.heso[i];
			}
		}
		return c;
	}
	DaThuc operator *(DaThuc b) {
		DaThuc c;
		c.n = b.n + this->n;
		c.heso = new float[c.n];
		for (int i = 0; i <= this->n; i++) {
			int k = i;
			for (int j = 0; j <= b.n; j++) {
				c.heso[k] = this->heso[i] * b.heso[j];
				k++;
			}
		}
		return c;
	}
	DaThuc();
	~DaThuc();
};


