#include<iostream>
#include"DaThuc.h"
using namespace std;

int main() {
	DaThuc a, b;
	cin >> a;
	cin >> b;
	cout << a + b;
	system("pause");
}