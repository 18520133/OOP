#include "gate.h"



gate::gate()
{
}


gate::~gate()
{
}
