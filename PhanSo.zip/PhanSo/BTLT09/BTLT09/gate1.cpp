#include "gate1.h"
#include <iostream>
using namespace std;


gate1::gate1()
{
}
void gate1::input()
{
	cout << "Enter the price: ";
	cin >> dongia;
	cout << "\nEnter the amount of product: ";
	cin >> sohang;
	money1 = dongia * sohang;
}
void gate1::output()
{
	cout << "The amout of money the prince need to pass: " << money1;
}
bool gate1::pass(prince &a)
{
	if (a.getmoney() > money1)
	{
		a.setmoney(a.getmoney() - money1);
		return true;
	}
	else
		return false;
}
gate1::~gate1()
{
}
