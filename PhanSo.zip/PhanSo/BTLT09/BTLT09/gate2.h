#pragma once
#include "gate.h"
#include "prince.h"
class gate2: public gate
{
private:
	float IQ1;
public:
	gate2();
	~gate2();
	void input();
	void output();
	bool pass(prince &a);
};

