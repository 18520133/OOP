#include "manage.h"
#include <iostream>
#include "gate1.h"
#include "gate2.h"
#include "gate3.h"
using namespace std;

manage::manage()
{
}
void manage::input()
{
	cout << "Enter the number of the gate: ";
	cin >> s;
	int flag;
	arr = new gate *[s];
	for (int i = 0; i < s; i++)
	{
		cout << "1:Business Gate          2:Academic Gate          3:Power Gate" << endl;
		cin >> flag;
		switch (flag)
		{
		case 1:
			arr[i] = new gate1();
			arr[i]->input();
			break;
		case 2:
			arr[i] = new gate2();
			arr[i]->input();
			break;
		case 3:
			arr[i] = new gate3();
			arr[i]->input();
			break;
		default:
			break;
		}
	}
}
void manage::output(prince &a)
{
	for (int i = 0; i < s; i++)
	{
		if (arr[i]->pass(a) == false)
		{
			cout << "sml";
			return;
		}
	}
	cout << "Mission suceed." << endl;
	a.output();
}
manage::~manage()
{
}
