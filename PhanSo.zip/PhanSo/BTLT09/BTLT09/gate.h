#pragma once
#include "prince.h"
class gate
{
public:
	gate();
	~gate();
	virtual void input() {}
	virtual void output() {}
	virtual bool pass(prince &a)
	{
		return true;
	}
};

