#include "prince.h"
#include <iostream>
using namespace std;


prince::prince()
{
}
void prince::input()
{
	cout << "Enter the prince's money: ";
	cin >> money;
	cout << "\nEnter IQ of prince: ";
	cin >> IQ;
	cout << "\nEnter the prince's power:  ";
	cin >> power;
}
void prince::output()
{
	cout << "Money: " << money;
	cout << "\nIQ: " <<IQ ;
	cout << "\nPower: " << power << endl;
}

prince::~prince()
{
}
