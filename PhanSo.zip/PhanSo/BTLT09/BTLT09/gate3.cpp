#include "gate3.h"
#include <iostream>
using namespace std;


gate3::gate3()
{
}
void gate3::input()
{
	cout << "The level of power the prince need to pass: ";
	cin >> power1;
}
void gate3::output()
{
	cout << "The level of power the prince need to pass: " << power1;
}
bool gate3::pass(prince &a)
{
	if (a.getpower() > power1)
	{
		a.setpower(a.getpower() - power1);
		return true;
	}
	else 
		return false;
}
gate3::~gate3()
{
}
