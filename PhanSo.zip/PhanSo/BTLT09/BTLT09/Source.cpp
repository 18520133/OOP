#include <iostream>
#include "gate.h"
#include "gate1.h"
#include "gate2.h"
#include "gate3.h"
#include "manage.h"
#include "prince.h"
using namespace std;
int main()
{
	prince a;
	a.input();
	manage QL;
	QL.input();
	QL.output(a);
	system("pause");
	return 0;
}