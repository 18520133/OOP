#include "gate2.h"
#include <iostream>
using namespace std;

gate2::gate2()
{
}
void gate2::input()
{
	cout << "The IQ the prince need to pass: ";
	cin >> IQ1;
}
void gate2::output()
{
	cout << "The amout of money the prince need to pass: " << IQ1;
}
bool gate2::pass(prince &a)
{
	if (a.getIQ() > IQ1)
		return true;
	else
		return false;
}
gate2::~gate2()
{
}
