#pragma once
#include "gate.h"
#include "prince.h"
class manage
{
private:
	int s;
	gate **arr;
public:
	manage();
	~manage();
	void input();
	void output(prince &a);
};

