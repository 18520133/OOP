#pragma once
#include "gate.h"
#include "prince.h"
class gate1: public gate
{
private:
	float money1,dongia;
	int sohang;
public:
	gate1();
	~gate1();
	void input();
	void output();
	bool pass(prince &a);
};

