#pragma once
class prince
{
private:
	float money, IQ, power;
public:
	prince();
	~prince();
	virtual void input();
	virtual void output();
	float getmoney()
	{
		return money;
	}
	void setmoney(float x)
	{
		money = x;
	};
	float getIQ()
	{
		return IQ;
	}
	float getpower()
	{
		return power;
	}
	void setpower(float x)
	{
		power = x;
	}
};

