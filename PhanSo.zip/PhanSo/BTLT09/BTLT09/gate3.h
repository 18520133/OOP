#pragma once
#include "gate.h"
class gate3: public gate
{
private:
	float power1;
public:
	gate3();
	~gate3();
	void input();
	void output();
	bool pass(prince &a);
};

