#include "officer.h"



officer::officer()
{
	ID = 1;
}
void officer::input()
{
	cout << "Working day(s):";
	cin >> songaylamviec;
	employee::input();
	salary = songaylamviec * 100000;
}
void officer::output()
{
	cout << "Working day(s): " << songaylamviec;
	employee::output();
}

officer::~officer()
{
}
