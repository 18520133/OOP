#pragma once
#include"employee.h"
#include <vector>
using namespace std;
class manage
{
private:
	employee **x;
	int n;
public:
	manage();
	~manage();
	void input();
	void output();
};

