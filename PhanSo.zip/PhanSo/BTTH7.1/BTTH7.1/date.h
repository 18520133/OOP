#pragma once
#include <iostream>
using namespace std;
class date
{
private:
	int d, m, y;
public:
	date();
	~date();
	void input();
	void output();
};

