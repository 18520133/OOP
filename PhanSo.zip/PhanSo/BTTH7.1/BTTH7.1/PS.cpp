#include "PS.h"
#include "employee.h"
#include<iostream>
using namespace std;


PS::PS()
{
	ID = 2;
}
void PS::input()
{
	cout << "Basic salary: ";
	cin >> luongcoban;
	cout << "\nNumbers of product: ";
	cin >> soSP;
	employee::input();
	salary = luongcoban + soSP * 5000;
}
void PS::output()
{
	cout << "Basic salary: " << luongcoban;
	cout << "\nNumbers of products: " << soSP;
	employee::output();
}

PS::~PS()
{
}
