#include "date.h"
#include <iostream>
using namespace std;


date::date()
{
}
void date::input()
{
	cout << "Enter day/month/year: ";
	cin >> d >> m >> y;
}
void date::output()
{
	cout << d << "/" << m<<"/" << y;
}
date::~date()
{
}
