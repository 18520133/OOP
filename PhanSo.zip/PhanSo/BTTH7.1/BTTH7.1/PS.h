#pragma once
#include<iostream>
#include "employee.h"
using namespace std;

class PS:public employee
{
private:
	int luongcoban, soSP;
public:
	PS();
	~PS();
	void input();
	void output();
};

