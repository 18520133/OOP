#include "date.h"
#include "employee.h"
#include "manage.h"
#include "officer.h"
#include "PS.h"
#include <iostream>
using namespace std;
int main()
{
	manage QL;
	QL.input();
	QL.output();
	system("pause");
	return 0;
}