#include "manage.h"
#include "PS.h"
#include"officer.h"


manage::manage()
{
	n = 0;
	x = new employee*[1000];
}


manage::~manage()
{
	delete[]x;
}
void manage::input()
{
	int k;
	cout << "n=";
	cin >> n;
	for (int i = 0;i<n ; i++)
	{
		cout << "\nType of employee: \n1-van phong\n2-san xuat\n";
		cin >> k;
		if (k == 1)
		{
			x[i] = new officer;
			((officer *)x[i])->input();
		}
		else
		{
			x[i] = new PS;
			((PS *)x[i])->input();
		}	
	}
}
void manage::output()
{
	cout << "Numbers of employee: " << n << "\n";
	for (int i = 0; i < n; i++)
	{
		cout << endl;
		x[i]->output();
		switch (x[i]->ID)
		{
		case 1:
			((officer *)x[i])->output();
			break;
		case 2:
			((PS *)x[i])->output();
			break;
		default:
			break;
		}
		cout << endl;
	}
}