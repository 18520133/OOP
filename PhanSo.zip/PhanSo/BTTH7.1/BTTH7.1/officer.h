#pragma once
#include "employee.h"
#include <iostream>
using namespace std;
class officer:public employee
{
private:
	int songaylamviec;
public:
	officer();
	~officer();
	void input();
	void output();
};

