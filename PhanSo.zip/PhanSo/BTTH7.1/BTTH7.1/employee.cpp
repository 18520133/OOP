#include "employee.h"
#include<iostream>
#include <string>
using namespace std;


employee::employee()
{
}
void employee::input()
{
	cout << "Name: ";
	cin.ignore();
	getline(cin, name);
	cout << "\nDOB: ";
	birth.input();
}
void employee::output()
{
	cout << "\nName: " << name;
	cout << "\nDOB: ";
	birth.output();
	cout <<"\nSalary: "<< salary;
}

employee::~employee()
{
}
