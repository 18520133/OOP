#pragma once
#include <iostream>
#include "date.h"
using namespace std;
class employee
{	
protected:
	string name;
	date birth;
	int salary;
public:
	int ID; // 1:NV van phong	2:NV san xuat
	employee();
	~employee();
	void input();
	void output();
};

