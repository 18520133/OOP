#include <iostream>
using namespace std;
#include "Dagiac.h"
#include "point.h"
int main()
{
	Dagiac a, b;
	cin >> a;
	cin >> b;
	cout << a;
	cout << b;
	cout << "Tong 2 da giac:\n";
	Dagiac c = a + b;
	cout << c;
	system("pause");
	return 0;
}