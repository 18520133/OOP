#pragma once
#include <iostream>
using namespace std;
#include "point.h"
class Dagiac
{
private:
	int n;
	point *a;
public:
	Dagiac();
	friend istream &operator>>(istream &is, Dagiac &p);
	friend ostream &operator<<(ostream &os, Dagiac p);
	Dagiac operator+(Dagiac b);
	~Dagiac();
};