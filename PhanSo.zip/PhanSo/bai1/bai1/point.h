#pragma once
#include <iostream>
using namespace std;
class point
{
private:
	float x;
	float y;
public:
	point();
	friend istream &operator>>(istream &is, point &p);
	friend ostream &operator<<(ostream &os, point p);
	~point();
}