#include "Polygon.h"
#include "Vertex.h"
#include <iostream>
using namespace std;
int main()
{
	Polygon a, b;
	cin >> a;
	cin >> b;
	Polygon c = a + b;
	cout << c;
	return 0;
}