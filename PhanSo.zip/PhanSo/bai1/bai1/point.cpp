#include "point.h"



point::point()
{
}
istream &operator>>(istream &is, point &p)
{
	cout << "Nhap toa do x va y:";
	is >> p.x >> p.y;
	return is;
}
ostream &operator<<(ostream &os, point p)
{
	os << "(" << p.x << ";" << p.y << ")";
	return os;
}
point::~point()
{
}