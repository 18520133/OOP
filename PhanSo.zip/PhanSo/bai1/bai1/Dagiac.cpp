#include "Dagiac.h"



Dagiac::Dagiac()
{
}
istream &operator>>(istream &is, Dagiac &p)
{
	do
	{
		cout << "Nhap so dinh";
		is >> p.n;
	} while (p.n < 3);
	p.a = new point[p.n + 1];
	for (int i = 0; i < p.n; i++)
		cin >> p.a[i];
	return is;
}
ostream &operator<<(ostream &os, Dagiac p)
{
	os << "Da giac: (";
	for (int i = 0; i < p.n - 1; i++)
		os << p.a[i] << ",";
	os << p.a[p.n - 1];
	os << ")\n";
	return os;
}
Dagiac Dagiac::operator+(Dagiac b)
{
	Dagiac c;
	c.n = n + b.n;
	c.a = new point[c.n + 1];
	for (int i = 0; i < n; i++)
		c.a[i] = a[i];
	for (int i = 0; i < b.n; i++)
		c.a[n + i] = b.a[i];
	return c;
}
Dagiac::~Dagiac()
{
}