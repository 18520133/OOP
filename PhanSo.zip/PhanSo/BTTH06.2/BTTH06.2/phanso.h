#pragma once
#include <iostream>
#include <math.h>
using namespace std;
class phanso
{
private:
	int tu;
	int mau;
public:
	phanso();
	phanso(int t)
	{
		set(t, 1);
	}
	void set(int t, int m)
	{
		tu = t;
		mau = m;
	}
	friend istream& operator>>(istream &is, phanso &p);
	friend ostream& operator<<(ostream &os, phanso p);
	friend bool operator==(phanso a, phanso b);
	friend bool operator!=(phanso a, phanso b);
	friend bool operator>(phanso a, phanso b);
	friend bool operator>=(phanso a, phanso b);
	friend bool operator<=(phanso a, phanso b);
	friend bool operator<(phanso a, phanso b);
	friend phanso operator+(phanso a, phanso b);
	friend phanso operator-(phanso a, phanso b);
	friend phanso operator/(phanso a, phanso b);
	friend phanso operator*(phanso a, phanso b);
	~phanso();
};

