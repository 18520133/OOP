#include <iostream>
#include "phanso.h"
int main()
{
	phanso a, b;
	cout << "Nhap phan so 1: ";
	cin >> a;
	cout << "\nNhap phan so 2: ";
	cin >> b;
	cout << a << endl;
	cout << b;
	phanso c;
	c = a + b;
	cout << "\na+b=" << c;
	c = a - b;
	cout << "\na-b=" << c;
	c = a * b;
	cout << "\na*b=" << c;
	c = a / b;
	cout << "\na/b=" << c;
	if (a == b)
		cout << "\na=b\n";
	else cout << "\na!=b\n";
	system("pause");
	return 0;

}