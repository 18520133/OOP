#include "phanso.h"
#include <iostream>
#include <math.h>
using namespace std;


phanso::phanso()
{
}
istream& operator>>(istream &is, phanso &p)
{
	do
	{
		cin >> p.tu >> p.mau;
	} while (p.mau == 0);
	return is;
}
ostream& operator<<(ostream &os, phanso p)
{
	cout << p.tu << "/" << p.mau;
	return os;
}
bool operator==(phanso a, phanso b)
{
	if ((a.tu / a.mau) == (b.tu / b.mau))
		return true;
	else
		return false;
}
bool operator!=(phanso a, phanso b)
{

	if ((a.tu / a.mau) !=(b.tu / b.mau))
		return true;
	else
		return false;
}
bool operator<(phanso a, phanso b)
{

	if ((a.tu / a.mau) < (b.tu / b.mau))
		return true;
	else
		return false;
}
bool operator<=(phanso a, phanso b)
{

	if ((a.tu / a.mau) <= (b.tu / b.mau))
		return true;
	else
		return false;
}
bool operator>(phanso a, phanso b)
{
	if ((a.tu / a.mau) > (b.tu / b.mau))
		return true;
	else
		return false;
}
bool operator>=(phanso a, phanso b)
{

	if ((a.tu / a.mau) >= (b.tu / b.mau))
		return true;
	else
		return false;
}
phanso operator+(phanso a, phanso b)
{
	phanso c;
	c.tu = a.tu*b.mau + b.tu*a.mau;
	c.mau = a.mau*b.mau;
	return c;
}
phanso operator-(phanso a, phanso b)
{
	phanso c;
	c.tu = a.tu*b.mau - b.tu*a.mau;
	c.mau = a.mau*b.mau;
	return c;
}
phanso operator*(phanso a, phanso b)
{
	phanso c;
	c.tu = a.tu*b.tu;
	c.mau = a.mau*b.mau;
	return c;
}
phanso operator/(phanso a, phanso b)
{
	phanso c;
	c.tu = a.tu*b.mau;
	c.mau = a.mau*b.tu;
	return c;
}
phanso::~phanso()
{
}
