#pragma once
#include <iostream>
#include <math.h>
using namespace std;
class CTimeSpan
{
private:
	int gio, phut, giay;
public:
	CTimeSpan();
	CTimeSpan(int h, int m, int s)
	{
		set(h, m, s);
	}
	void set(int h, int m, int s)
	{
		gio = h;
		phut = m;
		giay = s;
	}
	friend istream& operator>>(istream &is, CTimeSpan &t);
	friend ostream& operator<<(ostream &os, CTimeSpan t);
	friend bool operator==(CTimeSpan a, CTimeSpan b);
	friend bool operator!=(CTimeSpan a, CTimeSpan b);
	friend bool operator>(CTimeSpan a, CTimeSpan b);
	friend bool operator>=(CTimeSpan a, CTimeSpan b);
	friend bool operator<(CTimeSpan a, CTimeSpan b);
	friend bool operator<=(CTimeSpan a, CTimeSpan b);
	friend CTimeSpan operator+(CTimeSpan a, CTimeSpan b);
	friend CTimeSpan operator-(CTimeSpan a, CTimeSpan b);

	~CTimeSpan();
};

