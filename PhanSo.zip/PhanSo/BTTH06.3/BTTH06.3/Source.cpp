#include <iostream>
#include "CTimeSpan.h"
using namespace std;
int main()
{
	CTimeSpan a, b;
	cout << "Nhap thoi gian 1: ";
	cin >> a;
	cout << "\nNhap thoi gian 2:";
	cin>> b;
	CTimeSpan c;
	c = a + b;
	cout << "\na+b=" << c;
	c = a - b;
	cout << "\na-b=" << c;
	system("pause");
	return 0;
}