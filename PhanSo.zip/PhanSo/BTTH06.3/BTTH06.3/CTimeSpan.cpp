#include "CTimeSpan.h"
#include <iostream>
using namespace std;


CTimeSpan::CTimeSpan()
{
}
istream& operator>>(istream &is, CTimeSpan &t)
{
	do
	{
		cin >> t.gio >> t.phut >> t.giay;
	} while ((t.giay >= 60) && (t.phut >= 60));
	return is;
}
ostream& operator<<(ostream &os, CTimeSpan t)
{
	cout << t.gio << "h" << t.phut << "m" << t.giay << "s";
	return os;
}
bool operator==(CTimeSpan a, CTimeSpan b)
{
	if ((a.gio * 3600 + a.phut * 60 + a.giay) == (b.gio * 3600 + b.phut * 60 + b.giay))
		return true;
	else
		return false;
}
bool operator!=(CTimeSpan a, CTimeSpan b)
{
	if ((a.gio * 3600 + a.phut * 60 + a.giay) != (b.gio * 3600 + b.phut * 60 + b.giay))
		return true;
	else
		return false;
}
bool operator>(CTimeSpan a, CTimeSpan b)
{
	if ((a.gio * 3600 + a.phut * 60 + a.giay) > (b.gio * 3600 + b.phut * 60 + b.giay))
		return true;
	else
		return false;
}
bool operator>=(CTimeSpan a, CTimeSpan b)
{
	if ((a.gio * 3600 + a.phut * 60 + a.giay) >= (b.gio * 3600 + b.phut * 60 + b.giay))
		return true;
	else
		return false;
}
bool operator<(CTimeSpan a, CTimeSpan b)
{
	if ((a.gio * 3600 + a.phut * 60 + a.giay) < (b.gio * 3600 + b.phut * 60 + b.giay))
		return true;
	else
		return false;
}
bool operator<=(CTimeSpan a, CTimeSpan b)
{
	if ((a.gio * 3600 + a.phut * 60 + a.giay) <= (b.gio * 3600 + b.phut * 60 + b.giay))
		return true;
	else
		return false;
}
CTimeSpan operator+(CTimeSpan a, CTimeSpan b)
{
	CTimeSpan c;
	c.giay = a.giay + b.giay;
	c.phut = a.phut + b.phut;
	c.gio = a.gio + b.gio;
	if (c.giay >= 60)
	{
		c.phut = c.phut + c.giay % 60;
		c.giay = c.giay - c.giay%60*60;
	}
	if (c.phut >= 60)
	{
		c.gio = c.gio + c.phut % 60;
		c.phut = c.phut - c.phut % 60 * 60;
	}
	return c;
}
CTimeSpan operator-(CTimeSpan a, CTimeSpan b)
{
	CTimeSpan c;
	if (a.giay - b.giay < 0)
	{
		c.giay = a.giay + 60 - b.giay;
		c.phut = a.phut - 1;
	}
	else
		c.giay = a.giay - b.giay;
	if (a.phut - b.phut < 0)
	{
		c.phut = a.phut + 60 - b.phut;
		c.gio = c.gio - 1;
	}
	else
		c.phut = a.phut - b.phut;
	c.gio = a.gio - b.gio;
	return c;
}
CTimeSpan::~CTimeSpan()
{
}
