#include "PS.h"
#include <iostream>

using namespace std;

int main()
{
	PhanSo ps1, Tong, Hieu;
	PhanSo ps2, Tich, Thuong;
	ps1.Nhap();
	ps2.Nhap();
	Tong = ps1.Tong(ps2);
	Hieu = ps1.Hieu(ps2);
	Tich = ps1.Tich(ps2);
	Thuong = ps1.Thuong(ps2);
	cout << "Tong = ";
	Tong.Xuat();
	cout << "\nHieu = ";
	Hieu.Xuat();
	cout << "\nTich = ";
	Tich.Xuat();
	cout << "\nThuong = ";
	Thuong.Xuat();
	system("pause");
	return 0;
}