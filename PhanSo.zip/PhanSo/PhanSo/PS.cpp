#include "PS.h"
#include <iostream>

using namespace std;

PhanSo::PhanSo()
{
	iTuSo = 0;
	iMauSo = 1;
}

PhanSo::PhanSo(int x, int y)
{
	iTuSo = x;
	iMauSo = y;
}
PhanSo::PhanSo(PhanSo &b)
{
	iTuSo = b.iTuSo;
	iMauSo = b.iMauSo;
}
void PhanSo::Nhap()
{
	cout << "Nhap lan luot Tu va mau ";
	cin >> this->iTuSo >> this->iMauSo;
}
void PhanSo::Xuat()
{
	cout << this->iTuSo << "/" << this->iMauSo;
}
PhanSo PhanSo::Tong(PhanSo b)
{
	PhanSo c;
	c.iTuSo = this->iTuSo*b.iMauSo + this->iMauSo*b.iTuSo;
	c.iMauSo = this->iMauSo*b.iMauSo;
	return c;
}
PhanSo PhanSo::Hieu(PhanSo b)
{
	PhanSo c;
	c.iTuSo = this->iTuSo*b.iMauSo - this->iMauSo*b.iTuSo;
	c.iMauSo = this->iMauSo*b.iMauSo;
	return c;
}
PhanSo PhanSo::Tich(PhanSo b)
{
	PhanSo c;
	c.iTuSo = this->iTuSo*b.iTuSo;
	c.iMauSo = this->iMauSo*b.iMauSo;
	return c;
}
PhanSo PhanSo::Thuong(PhanSo b)
{
	PhanSo c;
	c.iTuSo = this->iTuSo*b.iMauSo;
	c.iMauSo = this->iMauSo*b.iTuSo;
	return c;
}

PhanSo::~PhanSo()
{
}
