#pragma once
	class PhanSo
	{
	private:
		int iTuSo;
		int iMauSo;
	public:
		void Nhap();
		void Xuat();
		PhanSo();
		PhanSo(int x, int y);
		PhanSo(PhanSo &b);
		int getTu()
		{
			return iTuSo;
		}
		int getMau()
		{
			return iMauSo;
		}
		void setTu(int x)
		{
			iTuSo = x;
		}
		void setMau(int x)
		{
			iMauSo = x;
		}
		PhanSo Tong(PhanSo b);
		PhanSo Hieu(PhanSo b);
		PhanSo Tich(PhanSo b);
		PhanSo Thuong(PhanSo b);
		~PhanSo();
	};

