#include"CString.h"
CString::CString()
{
}
CString::~CString()
{
}
ostream &operator<<(ostream &os, const CString &a)
{
	cout << a.s;
	return os;
}
istream &operator>>(istream &is, CString &a)
{
	getline(is, a.s);
	return is;
}
CString CString::operator+(const CString &a)
{
	CString z;
	z.s = s;
	z.s += a.s;
	return z;
}
void CString::operator=(const CString &a)
{
	s = a.s;
}
bool CString::operator<(const CString &a)
{
	if (s < a.s) return true;
	return false;
}
bool CString::operator<=(const CString &a)
{
	if (s <= a.s) return true;
	return false;
}
bool CString::operator>(const CString &a)
{
	if (s > a.s) return true;
	return false;
}
bool CString::operator>=(const CString &a)
{
	if (s >= a.s) return true;
	return false;
}
bool CString::operator==(const CString &a)
{
	if (s == a.s) return true;
	return false;
}
bool CString::operator!=(const CString &a)
{
	if (s != a.s) return true;
	return false;
}