#include"CString.h"
void main()
{
	CString s, x;
	cin >> s >> x;
	if (s > x) cout << "True";
	system("pause");
}
