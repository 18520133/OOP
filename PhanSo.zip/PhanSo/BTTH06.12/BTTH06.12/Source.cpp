#include<iostream>
using namespace std;
void operator<<(std::ostream& os, const char*)
{
	os.write("Entering the Hello program saying...\nHello, world.\nThen exiting...\n", 67);
}
int main()
{
	cout << "Hello, word.\n";
	system("pause");
	return 0;
}