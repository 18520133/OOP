#include "manage.h"
#include <iostream>
#include "triangle.h"
#include "quadrilateral.h"
using namespace std;


manage::manage()
{
}
void manage::input()
{
	cout << "s=";
	cin >> s;
	int flag;
	arr = new polygon *[s];
	for (int i = 0; i < s; i++)
	{
		cout << "1:triangle       2:quadrilateral\n";
		cin >> flag;
		switch (flag)
		{
		case 1:
			arr[i] = new triangle();
			((triangle *)arr[i])->input();
			break;
		case 2:
			arr[i] = new quadrilateral();
			((quadrilateral *)arr[i])->input();
			break;
		default:
			break;
		}
	}

}
void manage::output()
{
	for (int i = 0; i < s; i++)
	{
		if (arr[i]->n == 3)
			((triangle *)arr[i])->output();
		if (arr[i]->n == 4)
			((quadrilateral *)arr[i])->output();
	}
}

manage::~manage()
{
}
