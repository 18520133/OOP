#include "polygon.h"
#include<iostream>
using namespace std;


polygon::polygon()
{
}
void polygon::input()
{
	a = new point[n];
	for (int i = 0; i < n; i++)
	{
		cout << "Nhap toa do diem thu " << i + 1 << " :";
		a[i].input();
	}
}
void polygon::output()
{
	for (int i = 0; i < n; i++)
		a[i].output();
}
polygon::~polygon()
{
}
