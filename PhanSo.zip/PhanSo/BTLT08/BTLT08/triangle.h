#pragma once
#include "polygon.h"
class triangle:public polygon
{
public:
	triangle();
	~triangle();
	void input();
	void output();
};


