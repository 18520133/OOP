#pragma once
#include"polygon.h"
class quadrilateral:public polygon
{
public:
	quadrilateral();
	~quadrilateral();
	void input();
	void output();
};

