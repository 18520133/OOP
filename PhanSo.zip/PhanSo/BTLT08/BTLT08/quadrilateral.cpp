#include "quadrilateral.h"
#include <iostream>
using namespace std;


quadrilateral::quadrilateral()
{
	n = 4;
}
void quadrilateral::input()
{
	polygon::input();
}
void quadrilateral::output()
{
	polygon::output();
	cout << endl;
}

quadrilateral::~quadrilateral()
{
}
