#include "point.h"
#include "polygon.h"
#include"triangle.h"
#include"quadrilateral.h"
#include "manage.h"
#include <iostream>
using namespace std;
int main()
{
	manage QL;
	QL.input();
	QL.output();
	system("pause");
	return 0;
}