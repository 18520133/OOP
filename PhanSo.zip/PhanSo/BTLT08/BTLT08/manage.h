#pragma once
#include"polygon.h"
class manage
{
private:
	int s;
	polygon **arr;
public:
	manage();
	~manage();
	void input();
	void output();
};

