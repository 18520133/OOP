#pragma once
class point
{
private:
	float x, y;
public:
	point();
	~point();
	void input();
	void output();
};

