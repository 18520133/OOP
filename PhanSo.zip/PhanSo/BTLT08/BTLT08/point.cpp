#include "point.h"
#include<iostream>
using namespace std;


point::point()
{
}
void point::input()
{
	cout << "Enter the point";
	cin >> x >> y;
}
void point::output()
{
	cout << "(" << x << "," << y << ")"<<" ";
}

point::~point()
{
}
