#include "triangle.h"
#include <iostream>
using namespace std;


triangle::triangle()
{
	n = 3;
}
void triangle::input()
{
	polygon::input();
}
void triangle::output()
{
	polygon::output();
	cout << endl;
}

triangle::~triangle()
{
}
