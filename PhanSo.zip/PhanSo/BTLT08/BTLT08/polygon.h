#pragma once
#include"point.h"
class polygon
{
protected:
	point *a;
public:
	polygon();
	~polygon();
	int n;
	void input();
	void output();
};

