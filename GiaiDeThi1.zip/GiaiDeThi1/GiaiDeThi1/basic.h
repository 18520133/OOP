#pragma once
#include "service.h"
#include <iostream>
using namespace std;
class basic:public service
{
private:
	int feeclass;
	int classbasic;
public:
	basic();
	~basic();
	void input()
	{
		service::input();
		cout << "So luong lop da DK: ";
		cin >> classbasic;
	}
	void output()
	{
		service::output();
	}
	int money()
	{
		return (basic_fee + classbasic+100 + PT)*month;
	}
};

