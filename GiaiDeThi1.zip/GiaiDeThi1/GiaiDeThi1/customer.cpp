#include "customer.h"
#include <iostream>
using namespace std;


customer::customer()
{
}
void customer::input()
{
	cout << "Name :";
	cin.ignore();
	getline(cin, name);
	cout << "\nSocial ID: ";
	cin >> CMND;
	cout<<"\nName of service: ":
	cin >> combo;
	cout << "Using time: ";
	cin >> month;
}
void customer::output()
{
	cout << name << endl;
	cout << CMND << endl;
	switch (combo)
		case 1:
			cout << "Premium" << endl;
		case 2:
			cout << "Basic" << endl;
		case 3:
			cout << "Non-member" << endl;
	
}
customer::~customer()
{
}
