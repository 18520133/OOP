#include "manage.h"



manage::manage()
{
}
void manage::intput()
{
	cin >> n;
	a = new service *[n];
	for (int i = 0; i < n; i++)
	{
		int id;
		cout << "1:premium 2:Basic 3:Non-member";
		cin >> id;
		switch (id)
		{
		case 1:
		{
			a[i] = new premium();
			a[i]->input();
			break;
		}
		case 2:
		{
			a[i] = new basic();
			a[i]->input();
			break;
		}
		case 3:
		{
			a[i] = new nonmember();
			a[i]->input();
			break;
		}
		default:
			break;
		}
	}
}
void manage::search()
{
	int max = 0;
	for (int i = 0; i < n; i++)
		if (max < a[i]->money())
		{
			max = a[i]->money();
		}
	for (int i = 0; i < n; i++)
		if (a[i]->money() == max)
			a[i]->output();
}

manage::~manage()
{
}
