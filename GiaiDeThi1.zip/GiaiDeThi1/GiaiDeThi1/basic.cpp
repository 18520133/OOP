#include "basic.h"



basic::basic()
{
	PT = 100;
	basic_fee = 500;
}


basic::~basic()
{
}
