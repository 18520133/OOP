#include <iostream>
#include "manage.h"
using namespace std;
int main()
{
	manage p;
	p.intput();
	p.search();
	system("pause");
	return 0;
}