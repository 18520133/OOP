#pragma once
#include "service.h"
#include "premium.h"
#include "basic.h"
#include "nonmember.h"
#include <iostream>
using namespace std;
class manage
{
private:
	int n;
	service **a;
public:
	manage();
	~manage();
	void intput();
	void search();
};

