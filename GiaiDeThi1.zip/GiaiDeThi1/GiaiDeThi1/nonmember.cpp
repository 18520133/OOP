#include "nonmember.h"



nonmember::nonmember()
{
	PT = 200;
	basic_fee = 200;
}


nonmember::~nonmember()
{
}
