#pragma once
#include <string>
using namespace std;
class service
{
protected:
	string name;
	int CMND;
	int basic_fee;
	int PT;
	int month;
public:
	service();
	~service();
	virtual void input();
	virtual void output();
	virtual int money() = 0;
};

