#include "premium.h"



premium::premium()
{
	steam = 0;
	PT = 0;
	feeclass = 0;
	basic_fee = 1000;
}


premium::~premium()
{
}
