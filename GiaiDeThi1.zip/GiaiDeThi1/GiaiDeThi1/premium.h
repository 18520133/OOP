#pragma once
#include "service.h"
class premium:public service
{
private:
	int feeclass;
	int steam;
public:
	premium();
	~premium();
	void input()
	{
		service::input();
	}
	void output()
	{
		service::output();
	}
	int money()
	{
		return (basic_fee + PT + feeclass + steam)*month;
	}
};

