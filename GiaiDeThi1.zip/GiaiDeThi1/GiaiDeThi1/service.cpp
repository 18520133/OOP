#include "service.h"
#include <iostream>
using namespace std;


service::service()
{
}
void service::input()
{
	cout << "Name: ";
	cin.ignore();
	getline(cin, name);
	cout << "Social ID: ";
	cin >> CMND;
	cout << "Using time: ";
	cin >> month;
}
void service::output()
{
	cout << name << endl;
	cout << CMND << endl;
	cout << month << "month";
}
service::~service()
{
}
