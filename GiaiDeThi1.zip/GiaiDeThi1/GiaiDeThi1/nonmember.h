#pragma once
#include "service.h"
class nonmember:public service
{
public:
	nonmember();
	~nonmember();
	void input()
	{
		service::input();
	}
	void output()
	{
		service::output();
	}
	int money()
	{
		return (basic_fee + PT)*month;
	}
};

