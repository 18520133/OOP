#pragma once
#include <string>
using namespace std;
class customer
{
private:
	string name;
	int CMND;
	int combo;
	int month;
public:
	customer();
	~customer();
	void input();
	void output();
};

